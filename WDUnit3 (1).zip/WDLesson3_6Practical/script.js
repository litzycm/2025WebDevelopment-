// Challenge 2:  Create the function for the Average program.  Refer to the resource link in the HTML for assistance.


// Challenge 4:  Create the function for the Slope program.  Refer to the resource link in the HTML for assistance.


// Challenge 6:  Create the function for the BMI program.  Refer to the resource link in the HTML for assistance.